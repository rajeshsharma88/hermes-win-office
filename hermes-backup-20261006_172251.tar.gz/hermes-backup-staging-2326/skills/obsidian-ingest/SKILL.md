---
name: obsidian-ingest
description: Send external messages into an Obsidian vault Inbox.
version: 1.0.0
tags: [Obsidian, Inbox, Telegram, Webhook, Ingestion, Polling]
metadata:
  hermes:
    tags: [Obsidian, Inbox, Telegram, Webhook, Ingestion, Polling]
    related_skills: [obsidian]
---

# Obsidian External Ingestion

Use this skill when an external source (Telegram bot, webhook endpoint, API feed, clipper fallback) needs to deliver content into an Obsidian vault's `00 - Inbox/`.

The vault's own processing pipeline (Foreign Properties rule, Inbox → `01 - Notes/` routing) then applies normally — do not bypass it.

## Decision: polling vs webhook

| | Polling | Webhook |
|---|---|---|
| Complexity | Low — single `getUpdates` call per tick | Medium — ngrok tunnel + webhook registration |
| Latency | Configurable interval (e.g. 60s) | Instant (push) |
| Contention risk | Another long-poll client can cause 409 Conflict | No contention — push model |
| Infra | None | ngrok (or equivalent tunnel) on a local port |
| Best for | Light usage, 1-minute lag acceptable | Heavily-contended bot, instant delivery needed |

Start with polling. Switch to webhook when 409 Conflict persists across multiple ticks.

## Polling implementation

- Call `getUpdates` with `offset=last_update_id+1`, `timeout=10-20`, `allowed_updates=["message","edited_message"]`.
- On 409 Conflict: sleep ~3s, retry once. If the retry also returns 409, skip this tick — do not loop aggressively.
- On persistent 409 across multiple ticks: switch to webhook mode.
- Parse the JSON response; process only `message` and `edited_message` entries whose `from.id` matches the target user.
- Update `last_update_id` to the max `update_id` seen, regardless of whether the message was processed.

## Environment loading

- Never assume `TELEGRAM_BOT_TOKEN` or any vault/credential env var is set when the script is invoked via `terminal` or `cronjob_manage`.
- Load `.env` explicitly inside the script: read `HERMES_HOME/.env` (default `~/AppData/Local/hermes/.env` on Windows), parse `KEY=VALUE` lines, skip `#` comments, and call `os.environ.setdefault` for each. Only then check for required tokens.
- As a backup, export the same vars in the `cronjob_manage` `script` field, but the script must not depend on them.

## State and deduplication

- Persist state in `STATE_DIR` (e.g. `~/AppData/Local/hermes/state/`) as a JSON file.
- Track `last_update_id` so each poll starts after the last processed update.
- Track `known_message_hashes` — hash of `message_id:date:text` — so a restart never re-creates a note for a message already captured.
- Write state to disk immediately after processing, before returning, so a crash mid-tick does not lose the offset.

## Inbox note shape

- **Always write to `00 - Inbox/`, never directly to `01 - Notes/`.** External captures are transit-zone material.
- Keep frontmatter bare: a `Created: YYYY-MM-DD HH:MM` line plus the raw message body. Do not pre-fill `categories:`, `subjects:`, or other schema fields.
- Derive the filename from the first line of the message text: sanitize to alphanumeric/spaces/punctuation, strip control characters, truncate to ~80 chars, default to `Untitled task`.
- Handle filename collisions by appending `(1)`, `(2)`, etc. before the `.md` extension.

## Hermes cron job setup

- Schedule via `cronjob_manage` with `schedule: every 1m` and `deliver: telegram:<chat_id>`.
- Keep the `script` field self-contained: export env vars, invoke the Python script.
- Keep the cron prompt minimal: "run the script, report what it captured, do not add extra logic."
- If the script fails (e.g. 409 on every tick), the cron agent should report the failure — do not silently swallow it.

## Webhook mode

- Requires an ngrok tunnel (or equivalent) from a local port to a public URL.
- Register the webhook via `setWebhook` with the public URL, `secret_token`, and `allowed_updates`.
- Run a lightweight HTTP server (FastAPI/Flask) on the local port; the `/webhook` endpoint verifies `secret_token`, extracts the message, and writes to Inbox.
- Clean up: call `deleteWebhook` on shutdown.
- If ngrok or the tunnel library is unavailable, fall back to polling.

## Pitfalls

- **Do not write to `01 - Notes/` directly.** Anything bypassing `00 - Inbox/` skips the vault's Foreign Properties rule and the Inbox processing workflow. File it in Inbox first.
- **Do not pre-fill Obsidian schema fields** (`categories:`, `subjects:`, `type:`, `status:`) on captured notes. The Inbox processor strips foreign schemas and the user categorizes during processing. Pre-filling creates drift.
- **Do not trust env vars set by the caller.** A `cronjob_manage` job or a `terminal` call may not have `TELEGRAM_BOT_TOKEN` in its environment. The script must load `.env` itself.
- **Do not resolve `offset` from a stale/corrupt state file.** If `last_update_id` is missing or the state file is corrupted, start from 0 — a few duplicate captures are cheaper than silently dropping messages.
- **Do not loop on 409.** A single retry is the right shape; aggressive retry burns tokens and does not unblock the other poller.

## Related

- `obsidian` skill — vault path resolution, file tools, note conventions.
- The vault's own `00 - Inbox/CLAUDE.md` — Foreign Properties rule and Inbox processing workflow.
