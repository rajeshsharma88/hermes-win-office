---
name: hermes-cron-jobs
description: "Create and manage scheduled cron jobs in Hermes Agent."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes, cron, scheduling, automation, backup, no-agent, script-jobs]
    homepage: https://github.com/NousResearch/hermes-agent
---

# Hermes Cron Jobs

Create durable scheduled jobs that run scripts or prompts on a timer. Jobs survive process restarts (stored in `cron/jobs.json` + `cron/executions.db`) and are managed via `hermes cron` CLI, the `cronjob` tool, or `/cron` slash command.

## Quick Create

```bash
# Script-only job (no LLM, script stdout delivered verbatim)
hermes cron create "0 2 * * *" \
    --name "Backup Hermes" \
    --script "hermes-backup.sh" \
    --no-agent \
    --deliver local \
    --failure-deliver local

# Prompt-based job (LLM runs each tick)
hermes cron create "every 30m" \
    --name "Check disk space" \
    --prompt "Check disk usage on all mounted volumes and report any over 90%."

# With a skill attached
hermes cron create "every monday 9am" \
    --name "Weekly review" \
    --skill "weekly-review-planning" \
    --prompt "Run the weekly review planning routine."
```

## Script-Only Jobs (`--no-agent`)

Use when the task is deterministic and needs no LLM — backups, health checks, file monitors, CI pings.

**Rules:**
- Script path is relative to `~/.hermes/scripts/`. Place the script there and reference it by filename only — absolute paths and `~`-relative paths are rejected.
- `.sh` / `.bash` files run via bash; everything else runs via Python.
- Script stdout is delivered verbatim to the `--deliver` target. Empty stdout = silent run.
- `--failure-deliver local` suppresses failure notifications; omit to send failures to the same target as `--deliver`.
- 3-minute hard interrupt per run.

**Pitfall — script path:**
> The `--script` value must be a bare filename under `~/.hermes/scripts/`. Passing `C:\Users\...\scripts\foo.sh` or `~/scripts/foo.sh` fails with `Script path must be relative to...`. Always `cd ~/.hermes && hermes cron create ... --script foo.sh`.

## Schedule Formats

| Format | Example | When to use |
|--------|---------|-------------|
| ISO timestamp | `2026-09-22T02:00:00+05:30` | One-shot at a specific time |
| Duration | `30m`, `2h`, `1d` | Simple interval |
| "every" phrase | `every 1m`, `every 2h`, `every monday 9am` | Human-friendly recurring |
| 5-field cron | `0 2 * * *`, `*/15 * * * *` | Cron-expression control |

`--schedule-display` and `--schedule` are set from the same argument; the display string is what `hermes cron list` shows.

## Job Lifecycle

```bash
hermes cron list                  # Show all jobs (active + paused)
hermes cron run <job-id>         # Run now (ad-hoc)
hermes cron pause <job-id>        # Pause
hermes cron resume <job-id>      # Resume
hermes cron remove <job-id>      # Delete
hermes cron edit <job-id>        # Edit in editor
```

**Pitfall — paused state on create:**
> Omit `--paused` to create active. `--paused` creates the job disabled; you must `hermes cron resume <id>` before it fires. Use `--paused` when the job needs credential setup or manual verification before first run.

## Delivery Targets

| Target | Meaning |
|--------|---------|
| `local` | Inject output into the local profile's canonical Bot Chat |
| `telegram:<chat_id>` | Push to a Telegram chat |
| `discord:<channel_id>` | Push to a Discord channel |
| `platform:<chat_id>` | Push to a platform's chat |
| `bot-chat:<profile>` | Inject as a message the bot responds to |
| (omit) | Follows the agent's default delivery |

## Key Paths

```
~/.hermes/cron/jobs.json         # Job definitions
~/.hermes/cron/executions.db     # Run history (SQLite)
~/.hermes/cron/output/           # Script output artifacts
~/.hermes/scripts/               # Scripts referenced by --script
~/.hermes/logs/                  # Job log output (if script logs here)
```

## Backing Up Hermes State

When creating a backup job that archives the Hermes home directory (`~/.hermes/`), the naive `tar` of the full tree **times out** — the `cache/` directory alone contains 135K+ files. Stage selectively first.

**Procedure:**
1. Create a staging directory under `/tmp`
2. Copy only essential paths: `config.yaml`, `.env`, `auth.json`, `state.db`, `kanban.db`, `projects.db`, `shared-state.db`, `skills/`, `memories/`, `sessions/`, `cron/`, `scripts/`, `logs/` (recent only), `desktop-plugins/`, `skins/`, `pets/`, `tui-widgets/`, `SOUL.md`, `.hermes_history`, `.skills_prompt_snapshot.json`, `spawn-ledger.json`, `processes.json`, `channel_directory.json`, `gateway_state.json`, `provider_models_cache.json`
3. Exclude: `cache/*`, `models_dev_cache.json`, `node/*`, `audio_cache/*`, `image_cache/*`, `images/*`, `tmp/*`, `*.db-wal/shm`, lock files (`*.lock`, `gateway.pid`), `bootstrap-cache/*`, `pending_messages/*`, `sandboxes/*`, `terminal-sessions/*`, `bot_relay/*`, `.fire-*` locks, `.npm_lock_*`, `.restart_pending.json`
4. `tar -czf` the staging dir (small: ~4-5 MB vs. timeout on full tree)
5. Clone/pull the target git repo, commit + push

See `references/hermes-backup-script.md` for a working template.

## Pitfalls

- **Git push without credentials:** If the target repo is private, set `GH_TOKEN` in the script's environment (e.g., export from `.env` inside the script) or use `git credential` helpers. Public repos push without auth.
- **LF/CRLF warnings on Windows:** Git may warn `LF will be replaced by CRLF` on checkout — harmless, the push still succeeds.
- **Idempotency:** Guard against duplicate pushes. Check if the backup name already appears in `INDEX.md` before adding; the commit will be empty (nothing to commit) if the archive is identical — handle with `git commit ... || { log "nothing to commit"; exit 0; }`.
- **Script timeouts:** The 3-minute hard interrupt applies to cron jobs. For backups that may exceed this on first run (large state.db + skills), run `hermes cron run <id>` with a generous `timeout` in the terminal tool, or test the script standalone with `bash ~/.hermes/scripts/<name>.sh` before scheduling.

## References

- `references/hermes-backup-script.md` — working template for a Hermes full-backup cron script
