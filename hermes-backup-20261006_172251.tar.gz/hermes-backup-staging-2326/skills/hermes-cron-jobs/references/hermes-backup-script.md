---
name: hermes-backup-script
description: "Template for a Hermes full-backup shell script -- selective staging, git push to GitHub."
---

# Hermes Full-Backup Script Template

A working template for backing up the entire Hermes home directory to a GitHub repository via a cron job.

## Why selective staging

The Hermes home directory contains 100K+ files, mostly in `cache/`. A naive `tar` of the full tree times out. The solution: copy only essential files to a staging directory, then tar that.

## What to include

| Category | Paths |
|----------|-------|
| Config & state | `config.yaml`, `.env`, `auth.json`, `state.db`, `kanban.db`, `projects.db`, `shared-state.db`, `channel_directory.json`, `gateway_state.json`, `provider_models_cache.json`, `ollama_cloud_models_cache.json`, `context_length_cache.yaml` |
| Skills (knowledge base) | `skills/` (all skills across all categories) |
| Memory | `memories/` |
| Sessions (transcripts) | `sessions/` |
| Cron jobs | `cron/` |
| Scripts | `scripts/` |
| Desktop plugins | `desktop-plugins/` |
| Skins/themes | `skins/` |
| Pets | `pets/` |
| TUI widgets | `tui-widgets/` |
| Metadata | `SOUL.md`, `.hermes_history`, `.skills_prompt_snapshot.json`, `install_id`, `spawn-ledger.json`, `processes.json` |
| Logs (recent) | `logs/*.log` -- last 7 days only via `find -mtime -7` |

## What to exclude

`cache/*`, `models_dev_cache.json` (regenerable), `node/*`, `audio_cache/*`, `image_cache/*`, `images/*`, `tmp/*`, `*.db-wal`, `*.db-shm`, all `*.lock` files, `gateway.pid`, `gateway.lock`, `state.db.auto-maintenance.lock`, `kanban.db.dispatch.lock`, `kanban.db.init.lock`, `auth.lock`, `.fire-*` locks, `.jobs.lock`, `.tick.lock`, `.npm_lock_*`, `.restart_pending.json`, `bootstrap-cache/*`, `pending_messages/*`, `sandboxes/*`, `terminal-sessions/*`, `bot_relay/*`

## Full template

```bash
#!/bin/bash
# Hermes Full Backup -> GitHub
# Backs up essential Hermes data (config, skills, state, memories, sessions, etc.)
# Excludes regenerable/cache-heavy directories

set -euo pipefail

HERMES_HOME="/c/Users/Aarogya/AppData/Local/hermes"
REPO_URL="https://github.com/USERNAME/REPO.git"
BACKUP_DIR="/c/Users/Aarogya/OneDrive/hermes-backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_NAME="hermes-backup-${TIMESTAMP}"
LOG_FILE="/c/Users/Aarogya/AppData/Local/hermes/logs/backup-cron.log"
STAGING_DIR="/tmp/hermes-backup-staging-$$"

mkdir -p "$BACKUP_DIR" "$(dirname "$LOG_FILE")" "$STAGING_DIR"

log() { echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"; }

log "=== Hermes backup started ==="

# --- Stage essential files ---
log "Staging essential files..."

# Config & state
cp -r "$HERMES_HOME/config.yaml" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/.env" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/auth.json" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/state.db" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/kanban.db" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/projects.db" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/shared-state.db" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/channel_directory.json" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/gateway_state.json" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/provider_models_cache.json" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/ollama_cloud_models_cache.json" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/context_length_cache.yaml" "$STAGING_DIR/" 2>/dev/null || true

# Skills
if [ -d "$HERMES_HOME/skills" ]; then
    cp -r "$HERMES_HOME/skills" "$STAGING_DIR/" 2>/dev/null || true
fi

# Memories, sessions, cron, scripts, plugins, skins, pets, widgets
for dir in memories sessions cron scripts desktop-plugins skins pets tui-widgets; do
    if [ -d "$HERMES_HOME/$dir" ]; then
        cp -r "$HERMES_HOME/$dir" "$STAGING_DIR/" 2>/dev/null || true
    fi
done

# Recent logs (7 days)
if [ -d "$HERMES_HOME/logs" ]; then
    mkdir -p "$STAGING_DIR/logs"
    find "$HERMES_HOME/logs" -name "*.log" -mtime -7 -exec cp {} "$STAGING_DIR/logs/" \; 2>/dev/null || true
fi

# Metadata
for f in SOUL.md .hermes_history .skills_prompt_snapshot.json install_id spawn-ledger.json processes.json; do
    cp -r "$HERMES_HOME/$f" "$STAGING_DIR/" 2>/dev/null || true
done

log "Staged $(find "$STAGING_DIR" -type f 2>/dev/null | wc -l) files"

# --- Create archive ---
ARCHIVE_PATH="${BACKUP_DIR}/${BACKUP_NAME}.tar.gz"
log "Creating archive: $ARCHIVE_PATH"

tar -czf "$ARCHIVE_PATH" -C /tmp "hermes-backup-staging-$$" 2>> "$LOG_FILE" || {
    log "ERROR: tar failed"
    rm -rf "$STAGING_DIR"
    exit 1
}

ARCHIVE_SIZE=$(du -h "$ARCHIVE_PATH" | cut -f1)
log "Archive created: $ARCHIVE_SIZE"

# --- Git push ---
GH_TOKEN="${GH_TOKEN:-}"
PUSH_URL="$REPO_URL"
[ -n "$GH_TOKEN" ] && PUSH_URL="https://x-access-token:${GH_TOKEN}@github.com/USERNAME/REPO.git"

TEMP_REPO="/tmp/hermes-backup-repo-$$"
rm -rf "$TEMP_REPO"
mkdir -p "$TEMP_REPO"
cd "$TEMP_REPO"

git init --quiet
git config user.name "Hermes Backup"
git config user.email "backup@hermes.local"
git remote add origin "$PUSH_URL" 2>/dev/null || true

if git fetch --quiet origin main 2>/dev/null; then
    log "Existing repo, pulling..."
    git checkout -b main --quiet 2>/dev/null || git checkout main --quiet 2>/dev/null
    git pull --quiet origin main 2>/dev/null || true
else
    log "Fresh repository"
    git checkout -b main --quiet
fi

cp "$ARCHIVE_PATH" "$TEMP_REPO/"

# INDEX.md
if [ -f "$TEMP_REPO/INDEX.md" ] && ! grep -q "| ${BACKUP_NAME} |" "$TEMP_REPO/INDEX.md" 2>/dev/null; then
    echo "| ${BACKUP_NAME} | $(date +'%Y-%m-%d %H:%M:%S %Z') | ${ARCHIVE_SIZE} | ${BACKUP_NAME}.tar.gz |" >> "$TEMP_REPO/INDEX.md"
fi

# Manifest
cat > "$TEMP_REPO/${BACKUP_NAME}.manifest.txt" << EOF
Hermes Backup: ${BACKUP_NAME}
Date: $(date +'%Y-%m-%d %H:%M:%S %Z')
Hermes Home: ${HERMES_HOME}
Archive Size: ${ARCHIVE_SIZE}

Files included:
$(cd "$STAGING_DIR" && find . -type f | sed 's|^\./||' | sort)
EOF

cd "$TEMP_REPO"
git add -A
git commit -m "Hermes backup: ${BACKUP_NAME} ($(date +'%Y-%m-%d %H:%M'))" --quiet 2>> "$LOG_FILE" || {
    log "WARNING: Nothing new to commit"
    rm -rf "$TEMP_REPO" "$STAGING_DIR"
    exit 0
}

if git push --quiet origin main 2>> "$LOG_FILE"; then
    log "SUCCESS: Pushed backup to GitHub"
else
    log "ERROR: Git push failed"
    git log --oneline -5 2>/dev/null | tee -a "$LOG_FILE"
    git remote -v 2>/dev/null | tee -a "$LOG_FILE"
    rm -rf "$TEMP_REPO" "$STAGING_DIR"
    exit 1
fi

rm -rf "$TEMP_REPO" "$STAGING_DIR"
log "=== Hermes backup completed ==="
```

## Creating the cron job

```bash
cd ~/.hermes
hermes cron create "0 2 * * *" \
    --name "Hermes Full Backup to GitHub" \
    --script "hermes-backup.sh" \
    --no-agent \
    --deliver local \
    --failure-deliver local
```

## Testing before scheduling

```bash
bash ~/.hermes/scripts/hermes-backup.sh
```

Run standalone first -- the 3-minute cron hard interrupt can kill a first-run backup that touches large state.db + skills. Verify the archive lands on GitHub before scheduling.

## Restoring from backup

```bash
# Clone the repo
git clone https://github.com/USERNAME/REPO.git /tmp/hermes-restore
cd /tmp/hermes-restore

# Download the latest archive (or pull if already present)
# Extract
tar -xzf hermes-backup-XXXX.tar.gz -C /tmp/hermes-restore/staging

# Copy back to ~/.hermes (overwrite carefully -- back up current state first!)
cp -r /tmp/hermes-restore/staging/* ~/.hermes/
```