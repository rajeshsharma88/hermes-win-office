#!/usr/bin/env python3
"""
Telegram → Obsidian Inbox relay (v3).

Two-phase design:
  Phase 1 (push):  Sets up a Telegram webhook → ngrok tunnel → this server.
                    Telegram pushes new messages here; we write them to Inbox.
  Phase 2 (fallback poll): If webhook registration fails or ngrok is unavailable,
                    falls back to short-polling with a 409-contention retry.

Run with:
    python3 telegram_inbox_relay.py [--poll]

Environment:
  TELEGRAM_BOT_TOKEN  - from Hermes .env (auto-loaded from .env if not set)
  VAULT_PATH          - Obsidian vault path
  STATE_DIR           - persistent state directory
  PORT                - local webhook server port (default 8765)
  NGROK_AUTH_TOKEN    - optional, for ngrok auth (unnecessary on free tier)
"""

import os
import sys
import time
import json
import hashlib
import re
import argparse
from datetime import datetime, timezone
from urllib.parse import urljoin

os.environ.setdefault("no_proxy", "*")  # ngrok free tier can be flaky behind proxies

# --- Auto-load .env if TELEGRAM_BOT_TOKEN is not set ---
HERMES_HOME = os.environ.get(
    "HERMES_HOME",
    os.path.expanduser("~/AppData/Local/hermes"),
)
ENV_FILE = os.path.join(HERMES_HOME, ".env")
if not os.environ.get("TELEGRAM_BOT_TOKEN") and os.path.exists(ENV_FILE):
    with open(ENV_FILE, "r") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, value = line.partition("=")
                os.environ.setdefault(key.strip(), value.strip())

import requests
from fastapi import FastAPI, Request, HTTPException
import uvicorn

try:
    import ngrok
    HAS_NGROK = True
except ImportError:
    HAS_NGROK = False

TELEGRAM_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
if not TELEGRAM_TOKEN:
    print("ERROR: TELEGRAM_BOT_TOKEN not set", file=sys.stderr)
    sys.exit(1)

VAULT_PATH = os.environ.get(
    "VAULT_PATH", r"C:\Users\Aarogya\Documents\rajesh-sharma-os"
)
INBOX_DIR = os.path.join(VAULT_PATH, "00 - Inbox")
STATE_DIR = os.environ.get(
    "STATE_DIR", os.path.expanduser("~/AppData/Local/hermes/state")
)
MY_ID = "1498816933"
WEBHOOK_SECRET = os.environ.get("TELEGRAM_WEBHOOK_SECRET", "rajesh-inbox-2026")
PORT = int(os.environ.get("PORT", "8765"))
POLL_INTERVAL = int(os.environ.get("POLL_INTERVAL", "30"))  # seconds between poll ticks

STATE_FILE = os.path.join(STATE_DIR, "telegram_inbox_relay.state")
API_BASE = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}"

app = FastAPI()


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r") as f:
            return json.load(f)
    return {
        "mode": "unknown",          # "webhook" | "poll" | "unknown"
        "last_update_id": 0,
        "known_message_hashes": [],
        "ngrok_url": None,
    }


def save_state(state):
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f)


# ---------------------------------------------------------------------------
# Inbox writing
# ---------------------------------------------------------------------------

def sanitize_filename(text: str) -> str:
    text = text.strip()
    first_line = text.split("\n")[0].strip()
    slug = first_line if first_line else text[:60]
    slug = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", slug)
    slug = re.sub(r"\s+", " ", slug).strip()
    if not slug:
        slug = "Untitled task"
    return slug[:80]


def message_hash(msg) -> str:
    key = f"{msg['message_id']}:{msg.get('date','')}:{msg.get('text','')}"
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]


def write_inbox_note(text: str) -> str:
    os.makedirs(INBOX_DIR, exist_ok=True)
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")
    title_slug = sanitize_filename(text)
    content = f"Created: {now}\n\n{text}"

    base = f"{title_slug}.md"
    path = os.path.join(INBOX_DIR, base)
    if os.path.exists(path):
        counter = 1
        while os.path.exists(os.path.join(INBOX_DIR, f"{title_slug} ({counter}).md")):
            counter += 1
        path = os.path.join(INBOX_DIR, f"{title_slug} ({counter}).md")

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return os.path.relpath(path, VAULT_PATH)


def process_message(message: dict) -> dict:
    """Write a Telegram message as an Inbox note. Returns status dict."""
    from_info = message.get("from")
    if not from_info or str(from_info.get("id")) != MY_ID:
        return {"status": "skipped", "reason": "not_from_me"}

    text = message.get("text", "").strip()
    if not text:
        return {"status": "skipped", "reason": "no_text"}

    state = load_state()
    known_hashes = set(state.get("known_message_hashes", []))

    h = message_hash(message)
    if h in known_hashes:
        return {"status": "duplicate", "hash": h}

    known_hashes.add(h)
    state["known_message_hashes"] = list(known_hashes)
    save_state(state)

    rel_path = write_inbox_note(text)
    print(f"✓ Captured: {rel_path}")
    print(f"  {text[:120]}{'...' if len(text) > 120 else ''}")

    return {"status": "captured", "file": rel_path, "text": text, "hash": h}


# ---------------------------------------------------------------------------
# Webhook endpoint
# ---------------------------------------------------------------------------

@app.post("/webhook")
async def webhook(request: Request):
    token = request.query_params.get("secret_token", "")
    if token != WEBHOOK_SECRET:
        raise HTTPException(status_code=403, detail="bad secret")

    try:
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="bad json")

    message = body.get("message") or body.get("edited_message")
    if not message:
        return {"ok": True, "skipped": True}

    result = process_message(message)
    return {"ok": True, "result": result}


@app.get("/health")
async def health():
    state = load_state()
    return {
        "ok": True,
        "pid": os.getpid(),
        "mode": state.get("mode", "unknown"),
        "ngrok_url": state.get("ngrok_url"),
    }


# ---------------------------------------------------------------------------
# Telegram API helpers
# ---------------------------------------------------------------------------

def set_webhook(url: str) -> dict:
    resp = requests.post(
        f"{API_BASE}/setWebhook",
        json={
            "url": url,
            "secret_token": WEBHOOK_SECRET,
            "allowed_updates": ["message", "edited_message"],
        },
        timeout=15,
    )
    data = resp.json()
    if not data.get("ok"):
        print(f"WARNING: setWebhook failed: {data.get('description')}", file=sys.stderr)
    return data


def delete_webhook() -> dict:
    resp = requests.post(f"{API_BASE}/deleteWebhook", timeout=15)
    return resp.json()


def get_webhook_info() -> dict:
    try:
        return requests.get(f"{API_BASE}/getWebhookInfo", timeout=10).json().get("result", {})
    except Exception as e:
        print(f"Could not check webhook info: {e}", file=sys.stderr)
        return {}


# ---------------------------------------------------------------------------
# Ngrok
# ---------------------------------------------------------------------------

def start_tunnel(port: int) -> str | None:
    """Start an ngrok tunnel and return the public URL, or None on failure."""
    if not HAS_NGROK:
        print("ngrok Python library not available — webhook mode requires it.", file=sys.stderr)
        return None

    try:
        tunnels = ngrok.get_tunnels()
        if tunnels:
            url = tunnels[0].url
            print(f"Reusing existing ngrok tunnel: {url}")
            return url
    except Exception as e:
        print(f"Checking existing tunnels failed ({e}), will create new.", file=sys.stderr)

    try:
        listener = ngrok.listen(port)
        url = listener.url
        print(f"Ngrok tunnel established: {url}")
        return url
    except Exception as e:
        print(f"Ngrok tunnel failed: {e}", file=sys.stderr)
        return None


# ---------------------------------------------------------------------------
# Polling fallback
# ---------------------------------------------------------------------------

def poll_tick(state: dict) -> int:
    """One poll tick. Returns number of new messages captured."""
    last_id = state.get("last_update_id", 0)
    known_hashes = set(state.get("known_message_hashes", []))
    offset = last_id + 1 if last_id else None
    captured = 0

    params = {"timeout": 10, "allowed_updates": ["message", "edited_message"]}
    if offset:
        params["offset"] = offset

    resp = requests.get(f"{API_BASE}/getUpdates", params=params, timeout=15)
    if resp.status_code == 409:
        print("409 Conflict (another poller active) — skipping tick.", file=sys.stderr)
        return 0
    resp.raise_for_status()
    data = resp.json()
    if not data.get("ok"):
        print(f"WARNING: Telegram ok=False: {data.get('description')}", file=sys.stderr)
        return 0

    updates = data.get("result", [])
    new_last_id = last_id

    for update in updates:
        uid = update.get("update_id")
        if uid is not None:
            new_last_id = max(new_last_id, uid)

        message = update.get("message") or update.get("edited_message")
        if not message:
            continue
        from_info = message.get("from")
        if not from_info or str(from_info.get("id")) != MY_ID:
            continue
        text = message.get("text", "").strip()
        if not text:
            continue

        h = message_hash(message)
        if h in known_hashes:
            continue
        known_hashes.add(h)

        rel_path = write_inbox_note(text)
        captured += 1
        print(f"✓ Captured (poll): {rel_path}")

    state["last_update_id"] = new_last_id
    state["known_message_hashes"] = list(known_hashes)
    save_state(state)
    return captured


def run_poll_loop():
    """Polling fallback: short polls every POLL_INTERVAL seconds."""
    state = load_state()
    state["mode"] = "poll"
    save_state(state)
    print(f"Poll mode: checking every {POLL_INTERVAL}s for messages from you (ID {MY_ID}).")
    print("Press Ctrl+C to stop.\n")

    try:
        while True:
            n = poll_tick(state)
            if n:
                print(f"  → {n} new task(s) written to Inbox.\n")
            time.sleep(POLL_INTERVAL)
    except KeyboardInterrupt:
        print("\nStopped.")


# ---------------------------------------------------------------------------
# Webhook mode
# ---------------------------------------------------------------------------

def run_webhook_mode():
    os.makedirs(INBOX_DIR, exist_ok=True)

    # 1. Start ngrok tunnel
    public_url = start_tunnel(PORT)
    if not public_url:
        print("No ngrok tunnel — cannot use webhook mode. Falling back to poll.", file=sys.stderr)
        run_poll_loop()
        return

    webhook_url = f"{public_url}/webhook"
    print(f"Webhook URL: {webhook_url}")

    # 2. Register webhook
    info = get_webhook_info()
    current_url = info.get("url", "")

    if current_url != webhook_url:
        print("Registering webhook with Telegram...")
        result = set_webhook(webhook_url)
        if not result.get("ok"):
            print("Webhook registration failed — falling back to poll.", file=sys.stderr)
            run_poll_loop()
            return
        print("Webhook registered.")
    else:
        print("Webhook already pointing at this URL.")

    state = load_state()
    state["mode"] = "webhook"
    state["ngrok_url"] = webhook_url
    save_state(state)

    print(f"\nListening for messages from you (ID {MY_ID}) via webhook.")
    print(f"Server: 127.0.0.1:{PORT}  |  Public: {webhook_url}")
    print("Press Ctrl+C to stop.\n")

    try:
        uvicorn.run(app, host="127.0.0.1", port=PORT, log_level="warning")
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        print("Cleaning up webhook...")
        delete_webhook()
        state = load_state()
        state["mode"] = "unknown"
        state["ngrok_url"] = None
        save_state(state)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Telegram → Obsidian Inbox relay")
    parser.add_argument(
        "--poll",
        action="store_true",
        help="Force polling mode (skip webhook/ngrok)",
    )
    args = parser.parse_args()

    if args.poll:
        run_poll_loop()
    else:
        try:
            run_webhook_mode()
        except ImportError as e:
            print(f"Missing dependency for webhook mode: {e}", file=sys.stderr)
            print("Falling back to poll mode (--poll).", file=sys.stderr)
            run_poll_loop()
