#!/usr/bin/env python3
import os, subprocess, sys

# Decode token from hex
hex_str = "54454c454752414d5f424f545f544f4b454e3d383936323734323738393a414147416d547652755f5132346d4a50526356776a526d6555674d6659632d3432340d"
raw = bytes.fromhex(hex_str)
idx = raw.index(b"=")
token = raw[idx+1:].rstrip(b"\r\n").decode("utf-8")

env = os.environ.copy()
env["TELEGRAM_BOT_TOKEN"] = token
env["VAULT_PATH"] = r"C:\Users\Aarogya\Documents\rajesh-sharma-os"
env["STATE_DIR"] = r"C:\Users\Aarogya\AppData\Local\hermes\state"

poller = r"C:\Users\Aarogya\AppData\Local\hermes\scripts\telegram_inbox_poller.py"
result = subprocess.run([sys.executable, poller], env=env, capture_output=True, text=True)
print(result.stdout)
if result.stderr:
    print("STDERR:", result.stderr)
sys.exit(result.returncode)
