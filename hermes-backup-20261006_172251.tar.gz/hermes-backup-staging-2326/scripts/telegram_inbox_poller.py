#!/usr/bin/env python3
"""
Telegram → Obsidian Inbox poller (v2).

Long-polls your Telegram bot for new messages from you (ID 1498816933).
Each new message becomes a markdown note in 00 - Inbox/.

Retries on 409 Conflict (transient when multiple clients poll the same bot).
State persisted so restarts never re-capture old messages.

Environment:
  TELEGRAM_BOT_TOKEN  - from Hermes .env
  VAULT_PATH          - Obsidian vault path
  STATE_DIR           - persistent state directory
"""

import os
import sys
import time
import json
import hashlib
import re
from datetime import datetime, timezone

import requests

TELEGRAM_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
if not TELEGRAM_TOKEN:
    print("ERROR: TELEGRAM_BOT_TOKEN not set", file=sys.stderr)
    sys.exit(1)

VAULT_PATH = os.environ.get(
    "VAULT_PATH", r"C:\Users\Aarogya\Documents\rajesh-sharma-os"
)
INBOX_DIR = os.path.join(VAULT_PATH, "00 - Inbox")
STATE_DIR = os.environ.get(
    "STATE_DIR", os.path.expanduser("~/AppData/Local/hermes/state")
)
MY_ID = "1498816933"

STATE_FILE = os.path.join(STATE_DIR, "telegram_inbox_poller.state")
API_BASE = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}"


def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r") as f:
            return json.load(f)
    return {"last_update_id": 0, "known_message_hashes": []}


def save_state(state):
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f)


def sanitize_filename(text: str) -> str:
    text = text.strip()
    first_line = text.split("\n")[0].strip()
    slug = first_line if first_line else text[:60]
    slug = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", slug)
    slug = re.sub(r"\s+", " ", slug).strip()
    if not slug:
        slug = "Untitled task"
    return slug[:80]


def message_hash(msg) -> str:
    key = f"{msg['message_id']}:{msg.get('date','')}:{msg.get('text','')}"
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]


def save_note(title_slug: str, text: str, created: str) -> str:
    os.makedirs(INBOX_DIR, exist_ok=True)
    base = f"{title_slug}.md"
    path = os.path.join(INBOX_DIR, base)
    if os.path.exists(path):
        counter = 1
        while os.path.exists(os.path.join(INBOX_DIR, f"{title_slug} ({counter}).md")):
            counter += 1
        path = os.path.join(INBOX_DIR, f"{title_slug} ({counter}).md")
    content = f"Created: {created}\n\n{text}"
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return os.path.relpath(path, VAULT_PATH)


def poll_once(offset: int | None) -> dict | None:
    """One getUpdates call. Returns parsed JSON or None on retryable error."""
    params = {"timeout": 20, "allowed_updates": ["message", "edited_message"]}
    if offset is not None:
        params["offset"] = offset

    resp = requests.get(f"{API_BASE}/getUpdates", params=params, timeout=35)
    if resp.status_code == 409:
        # Conflict — another poller (Hermes gateway) is holding the bot.
        # Retry once after a short wait; if it persists, skip this tick.
        time.sleep(3)
        resp2 = requests.get(f"{API_BASE}/getUpdates", params=params, timeout=35)
        if resp2.status_code == 409:
            return None  # Give up this tick, next minute may work
        resp = resp2

    resp.raise_for_status()
    data = resp.json()
    if not data.get("ok"):
        print(f"WARNING: Telegram ok=False: {data.get('description')}", file=sys.stderr)
        return None
    return data


def poll():
    state = load_state()
    last_id = state["last_update_id"]
    known_hashes = set(state.get("known_message_hashes", []))
    offset = last_id + 1 if last_id else None

    data = poll_once(offset)
    if data is None:
        print("No updates this tick (poll contention or error).")
        return 0

    updates = data.get("result", [])
    if not updates:
        print("No new messages.")
        return 0

    new_last_id = last_id
    captured = []

    for update in updates:
        uid = update.get("update_id")
        if uid is not None:
            new_last_id = max(new_last_id, uid)

        message = update.get("message") or update.get("edited_message")
        if not message:
            continue

        from_info = message.get("from")
        if not from_info or str(from_info.get("id")) != MY_ID:
            continue

        text = message.get("text", "").strip()
        if not text:
            continue

        h = message_hash(message)
        if h in known_hashes:
            continue
        known_hashes.add(h)

        created_dt = datetime.fromtimestamp(
            message.get("date", time.time()), tz=timezone.utc
        )
        created_str = created_dt.strftime("%Y-%m-%d %H:%M")

        title_slug = sanitize_filename(text)
        rel_path = save_note(title_slug, text, created_str)

        captured.append((rel_path, text))
        print(f"✓ Captured: {rel_path}")
        print(f"  {text[:120]}{'...' if len(text) > 120 else ''}")

    state["last_update_id"] = new_last_id
    state["known_message_hashes"] = list(known_hashes)
    save_state(state)

    print(f"Done. {len(captured)} new task(s). Last update_id: {new_last_id}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(poll())
    except requests.RequestException as e:
        print(f"ERROR: Telegram API request failed: {e}", file=sys.stderr)
        sys.exit(2)
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(3)
