#!/bin/bash
# Hermes Full Backup → GitHub
# Backs up essential Hermes data (config, skills, state, memories, sessions, etc.)
# Excludes regenerable/cache-heavy directories

set -euo pipefail

HERMES_HOME="/c/Users/Aarogya/AppData/Local/hermes"
REPO_URL="https://github.com/rajeshsharma88/hermes-win-office.git"
BACKUP_DIR="/c/Users/Aarogya/OneDrive/hermes-backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_NAME="hermes-backup-${TIMESTAMP}"
LOG_FILE="/c/Users/Aarogya/AppData/Local/hermes/logs/backup-cron.log"
STAGING_DIR="/tmp/hermes-backup-staging-$$"

# Ensure dirs exist
mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$STAGING_DIR"

log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "=== Hermes backup started ==="

# --- Step 1: Stage essential files (skip cache-heavy dirs) ---
log "Staging essential files..."

# Config & state
cp -r "$HERMES_HOME/config.yaml" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/.env" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/auth.json" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/state.db" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/kanban.db" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/projects.db" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/shared-state.db" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/channel_directory.json" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/gateway_state.json" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/provider_models_cache.json" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/ollama_cloud_models_cache.json" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/context_length_cache.yaml" "$STAGING_DIR/" 2>/dev/null || true

# Skills (all of them — these are the knowledge base)
if [ -d "$HERMES_HOME/skills" ]; then
    cp -r "$HERMES_HOME/skills" "$STAGING_DIR/" 2>/dev/null || true
fi

# Memories
if [ -d "$HERMES_HOME/memories" ]; then
    cp -r "$HERMES_HOME/memories" "$STAGING_DIR/" 2>/dev/null || true
fi

# Sessions (transcripts — important historical data)
if [ -d "$HERMES_HOME/sessions" ]; then
    cp -r "$HERMES_HOME/sessions" "$STAGING_DIR/" 2>/dev/null || true
fi

# Cron jobs
if [ -d "$HERMES_HOME/cron" ]; then
    cp -r "$HERMES_HOME/cron" "$STAGING_DIR/" 2>/dev/null || true
fi

# Logs (recent ones only — last 7 days)
if [ -d "$HERMES_HOME/logs" ]; then
    mkdir -p "$STAGING_DIR/logs"
    find "$HERMES_HOME/logs" -name "*.log" -mtime -7 -exec cp {} "$STAGING_DIR/logs/" \; 2>/dev/null || true
fi

# Scripts
if [ -d "$HERMES_HOME/scripts" ]; then
    cp -r "$HERMES_HOME/scripts" "$STAGING_DIR/" 2>/dev/null || true
fi

# Desktop plugins
if [ -d "$HERMES_HOME/desktop-plugins" ]; then
    cp -r "$HERMES_HOME/desktop-plugins" "$STAGING_DIR/" 2>/dev/null || true
fi

# Skins
if [ -d "$HERMES_HOME/skins" ]; then
    cp -r "$HERMES_HOME/skins" "$STAGING_DIR/" 2>/dev/null || true
fi

# Pets
if [ -d "$HERMES_HOME/pets" ]; then
    cp -r "$HERMES_HOME/pets" "$STAGING_DIR/" 2>/dev/null || true
fi

# TUI widgets
if [ -d "$HERMES_HOME/tui-widgets" ]; then
    cp -r "$HERMES_HOME/tui-widgets" "$STAGING_DIR/" 2>/dev/null || true
fi

# SOUL.md and other metadata
cp -r "$HERMES_HOME/SOUL.md" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/.skills_prompt_snapshot.json" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/.hermes_history" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/install_id" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/spawn-ledger.json" "$STAGING_DIR/" 2>/dev/null || true
cp -r "$HERMES_HOME/processes.json" "$STAGING_DIR/" 2>/dev/null || true

log "Staged $(find "$STAGING_DIR" -type f 2>/dev/null | wc -l) files"

# --- Step 2: Create archive ---
ARCHIVE_PATH="${BACKUP_DIR}/${BACKUP_NAME}.tar.gz"
log "Creating archive: $ARCHIVE_PATH"

tar -czf "$ARCHIVE_PATH" -C /tmp "hermes-backup-staging-$$" 2>> "$LOG_FILE" || {
    log "ERROR: tar failed"
    rm -rf "$STAGING_DIR"
    exit 1
}

ARCHIVE_SIZE=$(du -h "$ARCHIVE_PATH" | cut -f1)
log "Archive created: $ARCHIVE_SIZE ($ARCHIVE_PATH)"

# --- Step 3: Clone / pull GitHub repo ---
GH_TOKEN="${GH_TOKEN:-}"
PUSH_URL="$REPO_URL"

if [ -n "$GH_TOKEN" ]; then
    PUSH_URL="https://x-access-token:${GH_TOKEN}@github.com/rajeshsharma88/hermes-win-office.git"
    log "Using GH_TOKEN for authentication"
fi

TEMP_REPO="/tmp/hermes-backup-repo-$$"
rm -rf "$TEMP_REPO"
mkdir -p "$TEMP_REPO"
cd "$TEMP_REPO"

git init --quiet
git config user.name "Hermes Backup"
git config user.email "backup@hermes.local"
git remote add origin "$PUSH_URL" 2>/dev/null || true

# Fetch and merge if there's existing content
if git fetch --quiet origin main 2>/dev/null; then
    log "Existing repo found, pulling..."
    git checkout -b main --quiet 2>/dev/null || git checkout main --quiet 2>/dev/null
    git pull --quiet origin main 2>/dev/null || true
else
    log "Fresh repository"
    git checkout -b main --quiet
fi

# --- Step 4: Copy to repo ---
cp "$ARCHIVE_PATH" "$TEMP_REPO/"

# Create/update INDEX.md
if [ -f "$TEMP_REPO/INDEX.md" ]; then
    # Check if this backup already exists in index
    if ! grep -q "| ${BACKUP_NAME} |" "$TEMP_REPO/INDEX.md" 2>/dev/null; then
        echo "| ${BACKUP_NAME} | $(date +'%Y-%m-%d %H:%M:%S %Z') | ${ARCHIVE_SIZE} | ${BACKUP_NAME}.tar.gz |" >> "$TEMP_REPO/INDEX.md"
    fi
else
    cat > "$TEMP_REPO/INDEX.md" << EOF
# Hermes Backup Index

| Backup | Date | Size | Archive |
|--------|------|------|---------|
| ${BACKUP_NAME} | $(date +'%Y-%m-%d %H:%M:%S %Z') | ${ARCHIVE_SIZE} | ${BACKUP_NAME}.tar.gz |
EOF
fi

# Create backup manifest
cat > "$TEMP_REPO/${BACKUP_NAME}.manifest.txt" << EOF
Hermes Backup: ${BACKUP_NAME}
Date: $(date +'%Y-%m-%d %H:%M:%S %Z')
Hermes Home: ${HERMES_HOME}
Archive Size: ${ARCHIVE_SIZE}

Files included:
$(cd "$STAGING_DIR" && find . -type f | sed 's|^\./||' | sort)
EOF

log "Repo files: $(ls "$TEMP_REPO" | wc -l)"

# --- Step 5: Commit and push ---
cd "$TEMP_REPO"
git add -A
git commit -m "Hermes backup: ${BACKUP_NAME} ($(date +'%Y-%m-%d %H:%M'))" --quiet 2>> "$LOG_FILE" || {
    log "WARNING: Nothing new to commit"
    rm -rf "$TEMP_REPO" "$STAGING_DIR"
    exit 0
}

if git push --quiet origin main 2>> "$LOG_FILE"; then
    log "SUCCESS: Pushed backup to GitHub"
else
    log "ERROR: Git push failed"
    git log --oneline -5 2>/dev/null | tee -a "$LOG_FILE"
    git remote -v 2>/dev/null | tee -a "$LOG_FILE"
    rm -rf "$TEMP_REPO" "$STAGING_DIR"
    exit 1
fi

# --- Cleanup ---
rm -rf "$TEMP_REPO" "$STAGING_DIR"
log "=== Hermes backup completed successfully ==="
