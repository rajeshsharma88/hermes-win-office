import os, sys
hex_str = "54454c454752414d5f424f545f544f4b454e3d383936323734323738393a414147416d547652755f5132346d4a50526356776a526d6555674d6659632d3432340d"
raw = bytes.fromhex(hex_str)
idx = raw.index(b"=")
value = raw[idx+1:].rstrip(b"\r\n").decode("utf-8")
os.environ["TELEGRAM_BOT_TOKEN"] = value
print("TELEGRAM_BOT_TOKEN SET")
