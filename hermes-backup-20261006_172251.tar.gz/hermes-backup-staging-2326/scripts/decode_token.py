#!/usr/bin/env python3
"""Decode hex dump of .env TELEGRAM_BOT_TOKEN line to get full token."""
hex_str = "54454c454752414d5f424f545f544f4b454e3d383936323734323738393a414147416d547652755f5132346d4a50526356776a526d6555674d6659632d3432340d"
raw = bytes.fromhex(hex_str)
# Find the = sign and extract everything after it
idx = raw.index(b"=")
value = raw[idx+1:].rstrip(b"\r\n").decode("utf-8")
print(f"TELEGRAM_BOT_TOKEN={value}")
print(f"Length: {len(value)}")
