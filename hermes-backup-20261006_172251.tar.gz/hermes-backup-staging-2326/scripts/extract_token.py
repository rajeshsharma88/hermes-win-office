# extract_token.py - extract TELEGRAM_BOT_TOKEN from .env
import re

with open(r"C:\Users\Aarogya\AppData\Local\hermes\.env", "r") as f:
    for line in f:
        line = line.strip()
        if line.startswith("TELEGRAM_BOT_TOKEN=") and not line.startswith("#"):
            # Extract value after =
            value = line.split("=", 1)[1]
            print(f"TELEGRAM_BOT_TOKEN={value}")
            break
