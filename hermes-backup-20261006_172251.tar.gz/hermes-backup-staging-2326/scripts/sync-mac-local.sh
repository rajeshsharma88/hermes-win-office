#!/bin/bash
# Bidirectional sync between the ACTIVE Windows Hermes home and
# github.com/rajeshsharma88/hermes-mac-local (a shared config repo the Mac
# also pushes to ~09:00 IST daily).
#
# Direction & conflict rules (deliberate, verified against the repo):
#   PULL : repo is authoritative for SOUL.md, memories/, and every skill that
#          the Mac owns/is-newer. Pulling keeps Windows up to date.
#   PUSH : only Windows-UNIQUE shareable files go up (skills the Mac does not
#          have, and Windows-only bot scripts). We NEVER overwrite the Mac's
#          canonical SOUL.md or its newer shared skills, and we never --delete.
#   SAFE : pull --rebase --autostash first (the Mac may push concurrently);
#          no force-push; .gitignore keeps secrets (.env/auth.json/config.yaml)
#          and runtime state out of git.
set -uo pipefail

ACTIVE_HOME="/c/Users/Aarogya/AppData/Local/hermes"
REPO="/c/Users/Aarogya/hermes-mac-local"
BRANCH="main"
LOG_FILE="$ACTIVE_HOME/logs/sync-mac-local.log"

mkdir -p "$(dirname "$LOG_FILE")"
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"; }

cd "$REPO" || { log "FATAL: repo $REPO missing"; exit 1; }

GIT_NAME="Hermes Sync"
GIT_EMAIL="imrajesh8800@gmail.com"

# ---- PULL: bring Windows fully up to date with the Mac ----
log "pulling origin/$BRANCH..."
git pull --rebase --autostash "origin" "$BRANCH" >/dev/null 2>&1 || {
    git pull "origin" "$BRANCH" >/dev/null 2>&1 || { log "ERROR: pull failed"; exit 1; }
}

# SOUL.md: repo (Atlas) is authoritative. Never push stock-hermes up.
if [ -f SOUL.md ]; then
    cp SOUL.md "$ACTIVE_HOME/SOUL.md" && log "SOUL.md <- repo (Atlas)"
fi

# memories/MEMORY.md: repo has the Mac's personal memory; merge new entries
# only when Windows has none yet (never clobber a populated local memory).
mkdir -p "$ACTIVE_HOME/memories"
if [ -f memories/MEMORY.md ]; then
    if [ ! -s "$ACTIVE_HOME/memories/MEMORY.md" ]; then
        cp memories/MEMORY.md "$ACTIVE_HOME/memories/MEMORY.md"
        log "memories/MEMORY.md <- repo"
    else
        log "memories/MEMORY.md: local non-empty, left intact (no merge)"
    fi
fi

# skills: pull repo skills down where local is missing or older
copied_down=0
while IFS= read -r p; do
    [ -n "$p" ] || continue
    [ -f "skills/$p" ] || continue
    d="$ACTIVE_HOME/$p"
    if [ ! -e "$d" ] || [ "skills/$p" -nt "$d" ]; then
        mkdir -p "$(dirname "$d")"
        cp "skills/$p" "$d" && copied_down=$((copied_down + 1))
    fi
done < <(find skills -name SKILL.md 2>/dev/null | sed 's|^\./||')
log "pulled $copied_down skill(s) from repo"

# ---- PUSH: only Windows-UNIQUE additions, additive only ----
pushed=0

# bot/helper scripts unique to Windows (repo already holds the Mac's _*.py set)
for f in "$ACTIVE_HOME"/*.py; do
    [ -e "$f" ] || continue
    bn=$(basename "$f")
    case "$bn" in
        telegram_task_bot.py|_p1.py|_p2.py|_p3.py|_p4.py|_v2.py|_trace.py \
        |_verify_bot.py|_bot_p1.py|_bot_test.py|_bot_test2.py|_bot_test3.py \
        |_bot_test4.py|_tok_test.py|_tok_test2.py) continue ;;
    esac
    if [ ! -e "$REPO/$bn" ]; then
        cp "$f" "$REPO/$bn" && pushed=$((pushed + 1))
    fi
done

# skills that exist ONLY on Windows -> add to repo at their own path
while IFS= read -r rel; do
    [ -n "$rel" ] || continue
    [ -f "$ACTIVE_HOME/skills/$rel" ] || continue
    if [ ! -f "skills/$rel" ]; then
        mkdir -p "$REPO/skills/$(dirname "$rel")"
        cp "$ACTIVE_HOME/skills/$rel" "$REPO/skills/$rel" && pushed=$((pushed + 1))
    fi
done < <(comm -23 \
    <(find "$ACTIVE_HOME/skills" -name SKILL.md 2>/dev/null | sed 's|^\./||' | sed "s|^$ACTIVE_HOME/||" | sed 's|^skills/|skills/|' | sort) \
    <(find skills -name SKILL.md 2>/dev/null | sed 's|^\./||' | sort))

log "pushed $pushed Windows-unique file(s) up"

# ---- commit + push if anything changed ----
git config user.name "$GIT_NAME"
git config user.email "$GIT_EMAIL"
git add -A
if git diff --cached --quiet; then
    log "nothing to push - already in sync"
else
    git commit -q -m "config sync (windows): $(date '+%Y-%m-%d %H:%M:%S')" >/dev/null 2>&1
    if git push "origin" "$BRANCH" >/dev/null 2>&1; then
        log "pushed to origin/$BRANCH OK"
    else
        log "ERROR: git push failed"
        git remote -v >> "$LOG_FILE" 2>&1
        exit 1
    fi
fi

echo "sync-mac-local: pulled $copied_down, pushed $pushed, HEAD $(git rev-parse --short HEAD)"
