import requests
token = '8962742789:AAG4amTvRu_Q24mJPRcwjRmUgMfgYc-424'
resp = requests.get(f'https://api.telegram.org/bot{token}/getMe', timeout=15)
print('Status:', resp.status_code)
print('Body:', resp.text)
